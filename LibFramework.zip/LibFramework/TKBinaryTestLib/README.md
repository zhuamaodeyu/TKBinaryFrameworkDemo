# TKBinaryTestLib

[![CI Status](https://img.shields.io/travis/抓猫的鱼/TKBinaryTestLib.svg?style=flat)](https://travis-ci.org/抓猫的鱼/TKBinaryTestLib)
[![Version](https://img.shields.io/cocoapods/v/TKBinaryTestLib.svg?style=flat)](https://cocoapods.org/pods/TKBinaryTestLib)
[![License](https://img.shields.io/cocoapods/l/TKBinaryTestLib.svg?style=flat)](https://cocoapods.org/pods/TKBinaryTestLib)
[![Platform](https://img.shields.io/cocoapods/p/TKBinaryTestLib.svg?style=flat)](https://cocoapods.org/pods/TKBinaryTestLib)

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

TKBinaryTestLib is available through [CocoaPods](https://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod 'TKBinaryTestLib'
```

## Author

抓猫的鱼, playtomandjerry@gmail.com

## License

TKBinaryTestLib is available under the MIT license. See the LICENSE file for more info.
